<script setup lang="ts">

const badInstall = ref(false)

onMounted( async () => {
    try{
        const url = useRuntimeConfig().public.BaseUri + useRuntimeConfig().public.BaseUrl;
        const {$initializeB24Frame, $axios} = useNuxtApp();
        const frame = await $initializeB24Frame();
        const data = frame.auth.getAuthData()
        if(!data) {badInstall.value = true; return}
        const verify = await $axios.verifyBitrixUser(data.access_token);
        if(!verify) {badInstall.value = true; return}
        await frame.callMethod('placement.bind',{
            PLACEMENT : "CRM_COMPANY_DETAIL_TAB",
            HANDLER : url,
            DESCRIPTION : "DESCRIPTION",
            LANG_ALL : {
                en : {
                    TITLE : "Minta",
                    DESCRIPTION : "DESCRIPTION"
                },
                ru : {
                    TITLE : "Minta",
                    DESCRIPTION : "Описание"
                }
            }        
        })
        await frame.callMethod('placement.unbind',{
            PLACEMENT : "LEFT_MENU",
            HANDLER : url
        })
        frame.installFinish();
    }catch(e){
        console.log(e)
        badInstall.value = true
    }
    
})

</script>
<template>

</template>