const orientation = [
  "horizontal",
  "vertical"
] as const

const color = [
  "air-primary",
  "air-primary-success",
  "air-primary-alert",
  "air-primary-copilot",
  "air-primary-warning",
  "default",
  "danger",
  "success",
  "warning",
  "primary",
  "secondary",
  "collab",
  "ai"
] as const

const variant = [
  "list",
  "card",
  "table"
] as const

const size = [
  "xs",
  "sm",
  "md",
  "lg"
] as const

export default {
  "slots": {
    "root": "relative",
    "fieldset": "flex gap-x-2",
    "legend": "mb-1.5 block text-(--b24ui-typography-label-color)",
    "item": ""
  },
  "variants": {
    "orientation": {
      "horizontal": {
        "fieldset": "flex-row"
      },
      "vertical": {
        "fieldset": "flex-col"
      }
    },
    "color": {
      "air-primary": {
        "item": "style-filled"
      },
      "air-primary-success": {
        "item": "style-filled-success"
      },
      "air-primary-alert": {
        "item": "style-filled-alert"
      },
      "air-primary-copilot": {
        "item": "style-filled-copilot"
      },
      "air-primary-warning": {
        "item": "style-filled-warning"
      },
      "default": {
        "item": "style-old-default"
      },
      "danger": {
        "item": "style-old-danger"
      },
      "success": {
        "item": "style-old-success"
      },
      "warning": {
        "item": "style-old-warning"
      },
      "primary": {
        "item": "style-old-primary"
      },
      "secondary": {
        "item": "style-old-secondary"
      },
      "collab": {
        "item": "style-old-collab"
      },
      "ai": {
        "item": "style-old-ai"
      }
    },
    "variant": {
      "list": {},
      "card": {
        "item": "cursor-pointer items-start border border-(--ui-color-design-outline-na-stroke) bg-(--ui-color-design-outline-na-bg) has-data-[state=checked]:border-(--b24ui-border-color)"
      },
      "table": {
        "item": "cursor-pointer border border-(--ui-color-design-outline-na-stroke) bg-(--ui-color-design-outline-na-bg) has-data-[state=checked]:bg-(--b24ui-background)/24 has-data-[state=checked]:border-(--b24ui-border-color) has-data-[state=checked]:text-(--b24ui-color) has-data-[state=checked]:z-[1]"
      }
    },
    "size": {
      "xs": {
        "fieldset": "gap-x-[12px] gap-y-[4px]",
        "legend": "text-(length:--ui-font-size-xs)"
      },
      "sm": {
        "fieldset": "gap-x-[14px] gap-y-[6px]",
        "legend": "text-(length:--ui-font-size-xs)"
      },
      "md": {
        "fieldset": "gap-x-[16px] gap-y-[8px]",
        "legend": "text-(length:--ui-font-size-sm)"
      },
      "lg": {
        "fieldset": "gap-x-[16px] gap-y-[8px]",
        "legend": "text-(length:--ui-font-size-sm)"
      }
    },
    "disabled": {
      "true": {}
    },
    "required": {
      "true": {
        "label": "after:content-['*'] after:ms-0.5 after:text-(--ui-color-accent-main-alert)"
      }
    }
  },
  "compoundVariants": [
    {
      "size": "xs" as typeof size[number],
      "variant": "card" as typeof variant[number],
      "class": {
        "item": "px-[13px] py-[7px] rounded-(--ui-border-radius-xs)"
      }
    },
    {
      "size": "sm" as typeof size[number],
      "variant": "card" as typeof variant[number],
      "class": {
        "item": "px-[13px] py-[9px] rounded-(--ui-border-radius-sm)"
      }
    },
    {
      "size": "md" as typeof size[number],
      "variant": "card" as typeof variant[number],
      "class": {
        "item": "px-[17px] py-[10px] rounded-(--ui-border-radius-md)"
      }
    },
    {
      "size": "lg" as typeof size[number],
      "variant": "card" as typeof variant[number],
      "class": {
        "item": "px-[23px] py-[12px] rounded-(--ui-border-radius-md)"
      }
    },
    {
      "size": "xs" as typeof size[number],
      "variant": "table" as typeof variant[number],
      "class": {
        "item": "px-[13px] py-[7px]"
      }
    },
    {
      "size": "sm" as typeof size[number],
      "variant": "table" as typeof variant[number],
      "class": {
        "item": "px-[13px] py-[9px]"
      }
    },
    {
      "size": "md" as typeof size[number],
      "variant": "table" as typeof variant[number],
      "class": {
        "item": "px-[17px] py-[10px]"
      }
    },
    {
      "size": "lg" as typeof size[number],
      "variant": "table" as typeof variant[number],
      "class": {
        "item": "px-[23px] py-[12px]"
      }
    },
    {
      "size": "xs" as typeof size[number],
      "variant": "table" as typeof variant[number],
      "orientation": "horizontal" as typeof orientation[number],
      "class": {
        "item": "first-of-type:rounded-s-(--ui-border-radius-xs) last-of-type:rounded-e-(--ui-border-radius-xs)",
        "fieldset": "gap-0 -space-x-px"
      }
    },
    {
      "size": "xs" as typeof size[number],
      "variant": "table" as typeof variant[number],
      "orientation": "vertical" as typeof orientation[number],
      "class": {
        "item": "first-of-type:rounded-t-(--ui-border-radius-xs) last-of-type:rounded-b-(--ui-border-radius-xs)",
        "fieldset": "gap-0 -space-y-px"
      }
    },
    {
      "size": "sm" as typeof size[number],
      "variant": "table" as typeof variant[number],
      "orientation": "horizontal" as typeof orientation[number],
      "class": {
        "item": "first-of-type:rounded-s-(--ui-border-radius-sm) last-of-type:rounded-e-(--ui-border-radius-sm)",
        "fieldset": "gap-0 -space-x-px"
      }
    },
    {
      "size": "sm" as typeof size[number],
      "variant": "table" as typeof variant[number],
      "orientation": "vertical" as typeof orientation[number],
      "class": {
        "item": "first-of-type:rounded-t-(--ui-border-radius-sm) last-of-type:rounded-b-(--ui-border-radius-sm)",
        "fieldset": "gap-0 -space-y-px"
      }
    },
    {
      "size": [
        "lg" as typeof size[number],
        "md" as typeof size[number]
      ],
      "variant": "table" as typeof variant[number],
      "orientation": "horizontal" as typeof orientation[number],
      "class": {
        "item": "first-of-type:rounded-s-(--ui-border-radius-md) last-of-type:rounded-e-(--ui-border-radius-md)",
        "fieldset": "gap-0 -space-x-px"
      }
    },
    {
      "size": [
        "lg" as typeof size[number],
        "md" as typeof size[number]
      ],
      "variant": "table" as typeof variant[number],
      "orientation": "vertical" as typeof orientation[number],
      "class": {
        "item": "first-of-type:rounded-t-(--ui-border-radius-md) last-of-type:rounded-b-(--ui-border-radius-md)",
        "fieldset": "gap-0 -space-y-px"
      }
    },
    {
      "variant": "table" as typeof variant[number],
      "disabled": true,
      "class": {
        "item": "cursor-not-allowed"
      }
    }
  ],
  "defaultVariants": {
    "size": "md" as typeof size[number],
    "variant": "list" as typeof variant[number],
    "color": "air-primary" as typeof color[number]
  }
}