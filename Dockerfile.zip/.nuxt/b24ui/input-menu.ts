const fieldGroup = [
  "horizontal",
  "vertical"
] as const

const size = [
  "xss",
  "xs",
  "sm",
  "md",
  "lg",
  "xl"
] as const

const color = [
  "air-primary",
  "air-primary-success",
  "air-primary-alert",
  "air-primary-copilot",
  "air-primary-warning",
  "default",
  "danger",
  "success",
  "warning",
  "primary",
  "secondary",
  "collab",
  "ai"
] as const

const type = [
  "file"
] as const

const colorItem = [
  "air-primary",
  "air-primary-success",
  "air-primary-alert",
  "air-primary-copilot",
  "air-primary-warning",
  "default",
  "danger",
  "success",
  "warning",
  "primary",
  "secondary",
  "collab",
  "ai"
] as const

export default {
  "slots": {
    "root": "isolate relative inline-flex items-center",
    "base": "w-full py-0 border-0 focus:outline-none disabled:cursor-not-allowed disabled:pointer-events-none disabled:select-none disabled:opacity-30 disabled:resize-none appearance-none transition duration-300 ease-linear transition-colors text-(--ui-color-base-1) style-blurred-bg-input hover:text-(--ui-color-base-1) focus:text-(--ui-color-base-1) active:text-(--ui-color-base-1) placeholder:text-(--ui-color-design-plain-na-content-secondary) font-[family-name:var(--ui-font-family-primary)] font-(--ui-font-weight-regular) align-middle",
    "leading": "absolute inset-y-0 start-0 flex items-center",
    "leadingIcon": "shrink-0 text-(--b24ui-icon-color)",
    "leadingAvatar": "shrink-0",
    "leadingAvatarSize": "",
    "trailing": "group absolute inset-y-0 end-0 flex items-center disabled:cursor-not-allowed disabled:opacity-30",
    "trailingIcon": "shrink-0 text-(--b24ui-icon-color)",
    "tag": "pointer-events-none select-none absolute z-10 -top-[7px] right-[14px] flex flex-col justify-center items-center",
    "content": "base-mode bg-(--ui-color-bg-content-primary) shadow-(--popup-window-box-shadow) rounded-(--ui-border-radius-xl) will-change-[opacity] motion-safe:data-[state=open]:animate-[scale-in_100ms_ease-out] motion-safe:data-[state=closed]:animate-[scale-out_100ms_ease-in] origin-(--reka-dropdown-menu-content-transform-origin) font-[family-name:var(--ui-font-family-primary)] relative isolate px-0 py-(--menu-popup-padding) pointer-events-auto",
    "viewport": "relative scroll-py-1 w-[240px] max-h-[40vh] overflow-x-hidden overflow-y-auto scrollbar-thin",
    "arrow": "fill-(--ui-color-bg-content-primary)",
    "group": "grid",
    "empty": "h-(--popup-window-delimiter-section-height) py-[8px] select-none outline-none whitespace-nowrap text-center text-(length:--ui-size-sm)/(--ui-font-line-height-lg) text-(--b24ui-typography-legend-color) font-(--ui-font-weight-normal)",
    "label": "w-full min-w-[195px] h-(--popup-window-delimiter-section-height) px-[18px] mt-(--menu-item-block-stack-space) flex flex-row rtl:flex-row-reverse items-center select-none outline-none whitespace-nowrap text-start text-(length:--ui-size-sm) text-(--b24ui-typography-legend-color) font-(--ui-font-weight-normal) after:ms-[10px] after:block after:flex-1 after:min-w-[15px] after:h-px after:bg-(--ui-color-divider-vibrant-default)",
    "separator": "my-[8px] mx-[18px] h-[1px] bg-(--ui-color-divider-vibrant-default)",
    "item": "group w-full min-w-[195px] h-[36px] px-[18px] mt-(--menu-item-block-stack-space) relative flex flex-row rtl:flex-row-reverse items-center select-none outline-none whitespace-nowrap cursor-pointer data-disabled:cursor-not-allowed data-disabled:opacity-30 data-disabled:select-none text-start text-(length:--ui-font-size-md) text-(--b24ui-typography-legend-color) hover:text-(--b24ui-typography-label-color) data-highlighted:not-data-disabled:text-(--b24ui-typography-label-color) data-[state=open]:text-(--b24ui-typography-label-color) data-[state=checked]:text-(--b24ui-typography-label-color) hover:bg-(--ui-color-divider-optical-1-alt) data-highlighted:bg-(--ui-color-divider-optical-1-alt) data-[state=open]:bg-(--ui-color-divider-optical-1-alt) transition-colors",
    "itemLeadingIcon": "shrink-0 size-[18px] text-(--ui-color-design-plain-content-icon-secondary) group-data-highlighted:not-data-disabled:text-(--ui-color-accent-main-primary) group-data-[state=open]:text-(--ui-color-accent-main-primary) group-data-[state=checked]:text-(--ui-color-accent-main-primary) transition-colors",
    "itemLeadingAvatar": "shrink-0 size-[16px]",
    "itemLeadingAvatarSize": "2xs",
    "itemLeadingChip": "shrink-0 size-[16px]",
    "itemLeadingChipSize": "sm",
    "itemTrailing": "ml-auto rtl:ml-0 rtl:mr-auto inline-flex gap-1.5 items-center",
    "itemTrailingIcon": "shrink-0 size-[24px] text-(--ui-color-design-plain-content-icon-secondary)",
    "itemWrapper": "flex-1 flex flex-col min-w-0",
    "itemLabel": "truncate ms-[2px] -mt-px group-data-[state=checked]:text-(--ui-color-accent-main-primary)",
    "itemDescription": "truncate -mt-[6px] text-(--b24ui-typography-description-color) text-(length:--ui-font-size-sm)",
    "tagsItem": "ps-[13px] pe-[6px] rounded-(--ui-border-radius-xs) h-(--main-ui-square-item-height) leading-(--main-ui-square-item-height) font-[family-name:var(--ui-font-family-primary)] font-(--ui-font-weight-regular) inline-flex items-center gap-1 data-disabled:cursor-not-allowed data-disabled:opacity-30 data-disabled:select-none text-(--ui-color-design-tinted-content) bg-(--ui-color-design-tinted-bg-alt)",
    "tagsItemText": "truncate max-w-[180px]",
    "tagsItemDelete": "cursor-pointer inline-flex items-center disabled:pointer-events-none text-(--b24ui-icon-color-secondary) hover:text-(--b24ui-icon-color-secondary-hover) transition-none",
    "tagsItemDeleteIcon": "",
    "tagsInput": ""
  },
  "variants": {
    "fieldGroup": {
      "horizontal": {
        "root": "group leading-none has-focus-visible:z-[1]",
        "base": "focus-visible:outline-none ring ring-inset ring-1 focus-visible:ring-2 group-not-only:group-first:rounded-e-3xl group-not-only:group-last:rounded-s-none group-not-last:group-not-first:rounded-none group-not-only:group-first:rounded-e-none group-not-only:group-last:rounded-s-none group-not-last:group-not-first:rounded-none group-not-only:group-first:border-e-0 group-not-only:group-not-first:border-s-0"
      },
      "vertical": {
        "root": "group has-focus-visible:z-[1]",
        "base": "focus-visible:outline-none ring ring-inset ring-1 focus-visible:ring-2 group-not-only:group-first:rounded-b-none group-not-only:group-last:rounded-t-none group-not-last:group-not-first:rounded-none"
      }
    },
    "noSplit": {
      "false": "group-not-only:not-first:after:content-[''] group-not-only:not-first:after:absolute group-not-only:not-first:after:top-[7px] group-not-only:not-first:after:bottom-[6px] group-not-only:not-first:after:left-0 group-not-only:not-first:after:w-px group-not-only:not-first:after:bg-current/30"
    },
    "size": {
      "xss": {
        "base": "[--main-ui-square-item-height:12px] h-[20px] gap-1 text-(length:--ui-font-size-4xs)/[normal]",
        "leading": "px-1",
        "trailing": "px-1",
        "leadingIcon": "size-[12px]",
        "leadingAvatarSize": "3xs",
        "trailingIcon": "size-[12px]",
        "itemLeadingAvatar": "size-[12px]",
        "itemLeadingAvatarSize": "3xs",
        "tagsInput": "text-(length:--ui-font-size-4xs)/[normal]",
        "tagsItem": "text-(length:--ui-font-size-5xs)/(--main-ui-square-item-height) gap-0.5",
        "tagsItemDeleteIcon": "size-[10px]"
      },
      "xs": {
        "base": "[--main-ui-square-item-height:16px] h-[24px] gap-1 text-(length:--ui-font-size-4xs)/[normal]",
        "leading": "px-1",
        "trailing": "px-1",
        "leadingIcon": "size-[14px]",
        "leadingAvatarSize": "3xs",
        "trailingIcon": "size-[14px]",
        "itemLeadingAvatar": "size-[14px]",
        "itemLeadingAvatarSize": "3xs",
        "tagsInput": "text-(length:--ui-font-size-xs)/[normal]",
        "tagsItem": "text-(length:--ui-font-size-5xs)/(--main-ui-square-item-height) gap-0.5",
        "tagsItemDeleteIcon": "size-[10px]"
      },
      "sm": {
        "base": "[--main-ui-square-item-height:20px] h-[28px] gap-1.5 text-(length:--ui-font-size-xs)/[normal]",
        "leading": "px-1.5",
        "trailing": "px-1.5",
        "leadingIcon": "size-[16px]",
        "leadingAvatar": "size-[16px]",
        "leadingAvatarSize": "2xs",
        "trailingIcon": "size-[16px]",
        "itemLeadingAvatar": "size-[16px]",
        "itemLeadingAvatarSize": "2xs",
        "tagsInput": "text-(length:--ui-font-size-sm)/[normal]",
        "tagsItem": "text-(length:--ui-font-size-5xs)/(--main-ui-square-item-height) gap-0.5",
        "tagsItemDeleteIcon": "size-[12px]"
      },
      "md": {
        "base": "[--main-ui-square-item-height:24px] h-[34px] gap-1.5 text-(length:--ui-font-size-lg)/[normal]",
        "leading": "px-2",
        "trailing": "px-2",
        "leadingIcon": "size-[18px]",
        "leadingAvatarSize": "2xs",
        "trailingIcon": "size-[18px]",
        "itemLeadingAvatarSize": "2xs",
        "tagsInput": "text-(length:--ui-font-size-lg)/[normal]",
        "tagsItem": "text-(length:--ui-font-size-sm)/(--main-ui-square-item-height) gap-[4px]",
        "tagsItemDeleteIcon": "size-[18px]"
      },
      "lg": {
        "base": "[--main-ui-square-item-height:28px] h-[38px] gap-2 text-(length:--ui-font-size-lg)/[normal]",
        "leading": "px-2",
        "trailing": "px-2",
        "leadingIcon": "size-[22px]",
        "leadingAvatarSize": "2xs",
        "trailingIcon": "size-[22px]",
        "itemLeadingAvatarSize": "2xs",
        "tagsInput": "text-(length:--ui-font-size-lg)/[normal]",
        "tagsItem": "text-(length:--ui-font-size-md)/(--main-ui-square-item-height) gap-1",
        "tagsItemDeleteIcon": "size-[22px]"
      },
      "xl": {
        "base": "[--main-ui-square-item-height:32px] h-[46px] gap-2 text-(length:--ui-font-size-2xl)/[normal]",
        "leading": "px-2",
        "trailing": "px-2",
        "leadingIcon": "size-[22px]",
        "leadingAvatarSize": "2xs",
        "trailingIcon": "size-[22px]",
        "itemLeadingAvatarSize": "2xs",
        "tagsInput": "text-(length:--ui-font-size-2xl)/[normal]",
        "tagsItem": "text-(length:--ui-font-size-xl)/(--main-ui-square-item-height) gap-1",
        "tagsItemDeleteIcon": "size-[22px]"
      }
    },
    "color": {
      "air-primary": {
        "base": "style-filled"
      },
      "air-primary-success": {
        "base": "style-filled-success"
      },
      "air-primary-alert": {
        "base": "style-filled-alert"
      },
      "air-primary-copilot": {
        "base": "style-filled-copilot"
      },
      "air-primary-warning": {
        "base": "style-filled-warning"
      },
      "default": {
        "base": "style-old-default"
      },
      "danger": {
        "base": "style-old-danger"
      },
      "success": {
        "base": "style-old-success"
      },
      "warning": {
        "base": "style-old-warning"
      },
      "primary": {
        "base": "style-old-primary"
      },
      "secondary": {
        "base": "style-old-secondary"
      },
      "collab": {
        "base": "style-old-collab"
      },
      "ai": {
        "base": "style-old-ai"
      }
    },
    "rounded": {
      "true": "rounded-(--ui-border-radius-3xl)",
      "false": "rounded-(--ui-border-radius-sm)"
    },
    "noPadding": {
      "true": {
        "base": "px-0"
      }
    },
    "noBorder": {
      "true": "ring-0 focus-visible:ring-0 style-transparent-bg"
    },
    "underline": {
      "true": "rounded-none ring-0 focus-visible:ring-0 style-transparent-bg border-b-1 border-b-(--ui-color-design-outline-stroke)"
    },
    "leading": {
      "true": ""
    },
    "trailing": {
      "true": ""
    },
    "loading": {
      "true": ""
    },
    "highlight": {
      "true": "ring ring-inset ring-(--b24ui-border-color)"
    },
    "type": {
      "file": "file:me-1.5 file:text-(--ui-color-design-plain-na-content-secondary) file:outline-none"
    },
    "virtualize": {
      "true": {
        "viewport": "p-1 isolate"
      },
      "false": {
        "viewport": ""
      }
    },
    "addNew": {
      "true": {
        "group": "",
        "item": "text-(--b24ui-typography-legend-color) data-highlighted:not-data-disabled:text-(--b24ui-typography-label-color) data-[state=checked]:text-(--b24ui-typography-label-color)",
        "itemLabel": "flex flex-row flex-nowrap items-center justify-start gap-2",
        "itemLeadingIcon": "size-[20px] rounded-full text-(--ui-color-base-white-fixed) bg-(--ui-color-design-selection-content-icon-secondary) group-data-highlighted:not-data-disabled:text-(--ui-color-base-white-fixed) group-data-highlighted:not-data-disabled:bg-(--ui-color-design-selection-content-icon) group-data-[state=checked]:text-(--ui-color-base-white-fixed) group-data-[state=checked]:bg-(--ui-color-design-selection-content-icon)"
      }
    },
    "multiple": {
      "true": {
        "root": "flex-wrap",
        "base": "py-[6px] ps-[6px] pe-[39px]",
        "tagsInput": "flex-1 border-0 bg-transparent ps-[6px] pe-[0px] py-0 placeholder:text-(--ui-color-design-plain-na-content-secondary) focus:outline-none disabled:cursor-not-allowed disabled:pointer-events-none disabled:select-none disabled:opacity-30 focus:ring-0 focus-visible:ring-0"
      },
      "false": {
        "base": "px-3 placeholder:text-(--ui-color-design-plain-na-content-secondary) focus:outline-none disabled:cursor-not-allowed disabled:pointer-events-none disabled:select-none disabled:opacity-30"
      }
    },
    "colorItem": {
      "air-primary": {
        "item": "style-filled"
      },
      "air-primary-success": {
        "item": "style-filled-success"
      },
      "air-primary-alert": {
        "item": "style-filled-alert"
      },
      "air-primary-copilot": {
        "item": "style-filled-copilot"
      },
      "air-primary-warning": {
        "item": "style-filled-warning"
      },
      "default": {
        "item": "style-old-default"
      },
      "danger": {
        "item": "style-old-danger"
      },
      "success": {
        "item": "style-old-success"
      },
      "warning": {
        "item": "style-old-warning"
      },
      "primary": {
        "item": "style-old-primary"
      },
      "secondary": {
        "item": "style-old-secondary"
      },
      "collab": {
        "item": "style-old-collab"
      },
      "ai": {
        "item": "style-old-ai"
      }
    }
  },
  "compoundVariants": [
    {
      "colorItem": [
        "air-primary" as typeof colorItem[number],
        "air-primary-success" as typeof colorItem[number],
        "air-primary-alert" as typeof colorItem[number],
        "air-primary-copilot" as typeof colorItem[number],
        "air-primary-warning" as typeof colorItem[number]
      ],
      "active": false,
      "class": {
        "item": "text-(--b24ui-background) data-highlighted:text-(--b24ui-background-hover) data-[state=open]:text-(--b24ui-background-hover)",
        "itemLeadingIcon": "text-(--b24ui-background) group-data-highlighted:text-(--b24ui-background-hover) group-data-[state=open]:text-(--b24ui-background-hover)"
      }
    },
    {
      "colorItem": [
        "air-primary" as typeof colorItem[number],
        "air-primary-success" as typeof colorItem[number],
        "air-primary-alert" as typeof colorItem[number],
        "air-primary-copilot" as typeof colorItem[number],
        "air-primary-warning" as typeof colorItem[number]
      ],
      "active": true,
      "class": {
        "item": "text-(--b24ui-background-active)",
        "itemLeadingIcon": "text-(--b24ui-background-active) group-data-[state=open]:text-(--b24ui-background-active)"
      }
    },
    {
      "colorItem": "default" as typeof colorItem[number],
      "active": false,
      "class": ""
    },
    {
      "colorItem": "default" as typeof colorItem[number],
      "active": true,
      "class": ""
    },
    {
      "colorItem": [
        "danger" as typeof colorItem[number],
        "success" as typeof colorItem[number],
        "warning" as typeof colorItem[number],
        "primary" as typeof colorItem[number],
        "secondary" as typeof colorItem[number],
        "collab" as typeof colorItem[number],
        "ai" as typeof colorItem[number]
      ],
      "active": false,
      "class": {
        "item": "text-(--b24ui-background-active) data-highlighted:text-(--b24ui-background-hover) data-[state=open]:text-(--b24ui-background-hover)",
        "itemLeadingIcon": "text-(--b24ui-icon) group-data-highlighted:text-(--b24ui-icon) group-data-[state=open]:text-(--b24ui-icon)"
      }
    },
    {
      "colorItem": [
        "danger" as typeof colorItem[number],
        "success" as typeof colorItem[number],
        "warning" as typeof colorItem[number],
        "primary" as typeof colorItem[number],
        "secondary" as typeof colorItem[number],
        "collab" as typeof colorItem[number],
        "ai" as typeof colorItem[number]
      ],
      "active": true,
      "class": {
        "item": "text-(--b24ui-background-active)",
        "itemLeadingIcon": "text-(--b24ui-background-active) group-data-[state=open]:text-(--b24ui-background-active)"
      }
    },
    {
      "size": "xss" as typeof size[number],
      "multiple": true,
      "class": {
        "base": "min-h-[20px] h-auto py-[2px] ps-[4px]"
      }
    },
    {
      "size": "xs" as typeof size[number],
      "multiple": true,
      "class": {
        "base": "min-h-[24px] h-auto py-[2px] ps-[4px]"
      }
    },
    {
      "size": "sm" as typeof size[number],
      "multiple": true,
      "class": {
        "base": "min-h-[28px] h-auto py-[4px] ps-[4px]"
      }
    },
    {
      "size": "md" as typeof size[number],
      "multiple": true,
      "class": {
        "base": "min-h-[34px] h-auto py-[4px] ps-[4px]"
      }
    },
    {
      "size": "lg" as typeof size[number],
      "multiple": true,
      "class": {
        "base": "min-h-[38px] h-auto py-[4px] ps-[4px]"
      }
    },
    {
      "size": "xl" as typeof size[number],
      "multiple": true,
      "class": {
        "base": "min-h-[46px] h-auto"
      }
    },
    {
      "highlight": false,
      "noBorder": false,
      "underline": false,
      "class": {
        "base": "ring ring-inset ring-(--ui-color-design-outline-stroke) focus-visible:ring-1 focus-visible:ring-inset focus-visible:ring-(--b24ui-border-color) hover:not-disabled:not-data-disabled:ring-1 hover:not-disabled:not-data-disabled:ring-inset hover:not-disabled:not-data-disabled:ring-(--b24ui-border-color) data-[state=open]:ring-1 data-[state=open]:ring-inset data-[state=open]:ring-(--b24ui-border-color)"
      }
    },
    {
      "highlight": true,
      "noBorder": false,
      "underline": false,
      "class": {
        "base": "ring ring-inset ring-(--b24ui-border-color) focus-visible:ring-1 focus-visible:ring-inset focus-visible:ring-(--b24ui-border-color) hover:ring-1 hover:ring-inset hover:ring-(--b24ui-border-color) data-[state=open]:ring-1 data-[state=open]:ring-inset data-[state=open]:ring-(--b24ui-border-color)"
      }
    },
    {
      "noBorder": false,
      "underline": true,
      "class": {
        "base": "focus-visible:border-(--b24ui-border-color) hover:border-(--b24ui-border-color) data-[state=open]:border-(--b24ui-border-color)"
      }
    },
    {
      "highlight": true,
      "noBorder": false,
      "underline": true,
      "class": {
        "base": "ring-0 border-b-(--b24ui-border-color)"
      }
    },
    {
      "highlight": true,
      "noBorder": true,
      "underline": false,
      "class": {
        "base": "ring-0"
      }
    },
    {
      "type": "file" as typeof type[number],
      "size": "xss" as typeof size[number],
      "class": "py-[2px]"
    },
    {
      "type": "file" as typeof type[number],
      "size": "xs" as typeof size[number],
      "class": "py-[4px]"
    },
    {
      "type": "file" as typeof type[number],
      "size": "sm" as typeof size[number],
      "class": "py-[5px]"
    },
    {
      "type": "file" as typeof type[number],
      "size": "md" as typeof size[number],
      "class": "py-[7px]"
    },
    {
      "type": "file" as typeof type[number],
      "size": "lg" as typeof size[number],
      "class": "py-[9px]"
    },
    {
      "type": "file" as typeof type[number],
      "size": "xl" as typeof size[number],
      "class": "py-[11px]"
    },
    {
      "leading": true,
      "noPadding": false,
      "size": "xss" as typeof size[number],
      "class": "ps-[20px]"
    },
    {
      "leading": true,
      "noPadding": false,
      "size": "xs" as typeof size[number],
      "class": "ps-[22px]"
    },
    {
      "leading": true,
      "noPadding": false,
      "size": "sm" as typeof size[number],
      "class": "ps-[28px]"
    },
    {
      "leading": true,
      "noPadding": false,
      "size": "md" as typeof size[number],
      "class": "ps-[32px]"
    },
    {
      "leading": true,
      "noPadding": false,
      "size": "lg" as typeof size[number],
      "class": "ps-[32px]"
    },
    {
      "leading": true,
      "noPadding": false,
      "size": "xl" as typeof size[number],
      "class": "ps-[32px]"
    },
    {
      "trailing": true,
      "noPadding": false,
      "size": "xss" as typeof size[number],
      "class": "pe-[20px]"
    },
    {
      "trailing": true,
      "noPadding": false,
      "size": "xs" as typeof size[number],
      "class": "pe-[22px]"
    },
    {
      "trailing": true,
      "noPadding": false,
      "size": "sm" as typeof size[number],
      "class": "pe-[28px]"
    },
    {
      "trailing": true,
      "noPadding": false,
      "size": "md" as typeof size[number],
      "class": "pe-[34px]"
    },
    {
      "trailing": true,
      "noPadding": false,
      "size": "lg" as typeof size[number],
      "class": "pe-[38px]"
    },
    {
      "trailing": true,
      "noPadding": false,
      "size": "xl" as typeof size[number],
      "class": "pe-[38px]"
    },
    {
      "loading": true,
      "leading": true,
      "class": {
        "leadingIcon": "size-[21px]"
      }
    },
    {
      "loading": true,
      "leading": false,
      "trailing": true,
      "class": {
        "trailingIcon": "size-[21px]"
      }
    },
    {
      "fieldGroup": [
        "horizontal" as typeof fieldGroup[number],
        "vertical" as typeof fieldGroup[number]
      ],
      "size": [
        "xl" as typeof size[number],
        "lg" as typeof size[number],
        "md" as typeof size[number]
      ],
      "rounded": false,
      "class": "rounded-(--ui-border-radius-md)"
    },
    {
      "fieldGroup": [
        "horizontal" as typeof fieldGroup[number],
        "vertical" as typeof fieldGroup[number]
      ],
      "size": "sm" as typeof size[number],
      "rounded": false,
      "class": "rounded-(--ui-border-radius-sm)"
    },
    {
      "fieldGroup": [
        "horizontal" as typeof fieldGroup[number],
        "vertical" as typeof fieldGroup[number]
      ],
      "size": "xs" as typeof size[number],
      "rounded": false,
      "class": "rounded-(--ui-border-radius-xs)"
    },
    {
      "fieldGroup": [
        "horizontal" as typeof fieldGroup[number],
        "vertical" as typeof fieldGroup[number]
      ],
      "size": "xss" as typeof size[number],
      "rounded": false,
      "class": "rounded-[5px]"
    }
  ],
  "defaultVariants": {
    "color": "air-primary" as typeof color[number],
    "size": "md" as typeof size[number]
  }
}