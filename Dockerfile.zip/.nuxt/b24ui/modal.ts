const overlayBlur = [
  "auto",
  "on",
  "off"
] as const

export default {
  "slots": {
    "overlay": "fixed inset-0",
    "content": "base-mode bg-(--ui-color-bg-content-primary) flex flex-col gap-[20px] focus:outline-none p-[24px] pt-[20px]",
    "contentWrapper": "flex flex-col gap-[15px] pt-[4px]",
    "header": "flex items-start justify-between gap-[6px]",
    "wrapper": "",
    "body": "flex-1 text-(length:--ui-font-size-md) leading-normal",
    "footer": "flex items-center justify-between gap-[10px] border-t border-t-1 border-t-(--ui-color-divider-default) pt-[18px]",
    "title": "font-[family-name:var(--ui-font-family-primary)] text-(--b24ui-typography-label-color) font-(--ui-font-weight-medium) mb-0 text-[calc(var(--ui-font-size-2xl)+2px)]/(--ui-font-size-2xl)",
    "description": "mt-1 text-(--b24ui-typography-description-color) text-(length:--ui-font-size-sm)",
    "close": "-mt-[4px]"
  },
  "variants": {
    "overlayBlur": {
      "auto": {
        "overlay": "motion-safe:backdrop-blur-[2px]"
      },
      "on": {
        "overlay": "backdrop-blur-[2px]"
      },
      "off": {
        "overlay": ""
      }
    },
    "transition": {
      "true": {
        "overlay": "motion-safe:data-[state=open]:animate-[fade-in_200ms_ease-out] motion-safe:data-[state=closed]:animate-[fade-out_200ms_ease-in]",
        "content": "motion-safe:data-[state=open]:animate-[scale-in_200ms_ease-out] motion-safe:data-[state=closed]:animate-[scale-out_200ms_ease-in]"
      }
    },
    "fullscreen": {
      "true": {
        "content": "inset-0"
      },
      "false": {
        "content": "w-[calc(100vw-2rem)] max-w-[32rem] rounded-[calc(var(--ui-border-radius-xl)-2px)] shadow-lg",
        "contentWrapper": ""
      }
    },
    "overlay": {
      "true": {
        "overlay": "bg-[#003366]/20"
      }
    },
    "scrollable": {
      "true": {
        "overlay": "overflow-y-auto",
        "content": "relative"
      },
      "false": {
        "content": "fixed",
        "body": "overflow-y-auto"
      }
    },
    "scrollbarThin": {
      "true": {
        "body": "scrollbar-thin"
      }
    }
  },
  "compoundVariants": [
    {
      "scrollable": true,
      "fullscreen": false,
      "class": {
        "overlay": "grid place-items-center p-4 sm:py-8"
      }
    },
    {
      "scrollable": false,
      "fullscreen": false,
      "class": {
        "content": "top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 max-h-[calc(100dvh-2rem)] sm:max-h-[calc(100dvh-4rem)]",
        "contentWrapper": "overflow-hidden"
      }
    }
  ],
  "defaultVariants": {
    "scrollbarThin": true,
    "overlayBlur": "auto" as typeof overlayBlur[number]
  }
}