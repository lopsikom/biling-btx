
import { defuFn } from 'defu'

const inlineConfig = {
  "nuxt": {},
  "version": "2.2.1",
  "b24ui": {
    "tv": {
      "twMergeConfig": {}
    }
  }
}

/** client **/
import { _replaceAppConfig } from '#app/config'

// Vite - webpack is handled directly in #app/config
if (import.meta.dev && !import.meta.nitro && import.meta.hot) {
  import.meta.hot.accept((newModule) => {
    _replaceAppConfig(newModule.default)
  })
}
/** client-end **/

import cfg0 from "C:/Users/kvfilat/biling-btx/app/app.config.ts"

export default /*@__PURE__*/ defuFn(cfg0, inlineConfig)
