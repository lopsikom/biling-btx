/// <reference types="@nuxt/eslint" />
/// <reference types="@pinia/nuxt" />
/// <reference types="@bitrix24/b24ui-nuxt" />
/// <reference types="@nuxtjs/google-fonts" />
/// <reference types="@vueuse/nuxt" />
/// <reference types="@bitrix24/b24jssdk-nuxt" />
/// <reference types="@nuxt/telemetry" />
/// <reference types="reka-ui" />
/// <reference path="types/modules.d.ts" />
/// <reference path="types/runtime-config.d.ts" />
/// <reference path="types/app.config.d.ts" />
/// <reference types="nuxt" />
/// <reference types="../node_modules/@nuxt/vite-builder/dist/index.mjs" />
/// <reference types="C:/Users/kvfilat/biling-btx/node_modules/@nuxt/nitro-server/dist/index.mjs" />
/// <reference path="eslint-typegen.d.ts" />
/// <reference path="types/nitro-middleware.d.ts" />
/// <reference path="schema/nuxt.schema.d.ts" />

export {}
